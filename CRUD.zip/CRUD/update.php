<?php include "functions.php";?>
<?php include "dbConnection.php";?>

<?php

global $connect;
if($connect){
    $query="SELECT * FROM information";
    $run_Query= mysqli_query($connect,$query);
    }
    else{
        die("Login Failed");
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Homepage</title>
</head>
<body>

<form action="update.php" method="post">

<input type="text" name="username" id="" placeholder="Username"><br><br>
<input type="password" name="password" id="" placeholder="Password"><br><br>
<input type="submit" value="Update" name="submit">
<select name="id" id="id">
<?php

while($my_Query=mysqli_fetch_array($run_Query)){
    $id = $my_Query['id'];
  echo "<option value='$id'>$id</option>";  
}

?>

</select>

</form>

</body>
</html>

<?php
if(isset($_POST['submit'])){
    update();
}
?>