<?php include "dbConnection.php";


function insert(){
if(isset($_POST['submit'])){
    global $connect;
    $uname= $_POST['username'];
    $upass= $_POST['password'];
 
$query="INSERT INTO information (username,password) VALUES ('$uname','$upass')";
$run_Query= mysqli_query($connect,$query);
if($run_Query){
    echo "Data Inserted";
}
else{

    echo "Data not insert";
}

}
}


function read(){
    global $connect;
if($connect){
    $query="SELECT * FROM information";
    $run_Query= mysqli_query($connect,$query);
    while($my_Query=mysqli_fetch_array($run_Query)){
        echo $my_Query['id'].".";
        echo $my_Query['username']."<br>";    
    }
    }
    else{
        die("Login Failed");
    }
}



function update(){
    if(isset($_POST['submit'])){
        global $connect;
        $uname= $_POST['username'];
        $upass= $_POST['password'];
        $id = $_POST['id'];
if($connect){
    $query="UPDATE information SET username='$uname',password='$upass' WHERE id='$id'";
    $run_Query= mysqli_query($connect,$query);
    if($run_Query){
        echo "Data Updated";
    }else{
        echo "Problem updating data.";
    }
    }
    else{
        die("Login Failed");
    }
}
}





function delete(){
    if(isset($_POST['submit'])){
        global $connect;
        $id = $_POST['id'];
if($connect){
    $query="DELETE FROM information WHERE id='$id'";
    $run_Query= mysqli_query($connect,$query);
    if($run_Query){
        echo "Row Deleted";
    }else{
        echo "Problem Deleting row";
    }
    }
    else{
        die("Login Failed");
    }
}
}




function login(){
    if(isset($_POST['submit'])){
        global $connect;
        $uname= $_POST['username'];
        $upass= $_POST['password'];
if($connect){
    $query="SELECT * FROM information WHERE username='$uname' AND password='$upass'";
    $run_Query= mysqli_query($connect,$query);
    while($my_Query=mysqli_fetch_array($run_Query)){
        echo "Welcome ".$my_Query['username'];    
    }
    }
    else{
        echo "Login Failed";
    }
}
}



?>



