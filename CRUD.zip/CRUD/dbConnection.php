<?php
$connect = mysqli_connect('localhost','root','','crud');
if(!$connect){
    echo "Connection Failed";
}
?>

