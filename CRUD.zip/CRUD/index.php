<?php include "functions.php";?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Homepage</title>
</head>
<body>

<form action="index.php" method="post">

<input type="text" name="username" id="" placeholder="Username"><br><br>
<input type="password" name="password" id="" placeholder="Password"><br><br>
<input type="submit" value="Login" name="submit">

</form>

</body>
</html>

<?php
if(isset($_POST['submit'])){
    login();
}
?>