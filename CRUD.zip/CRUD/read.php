<?php include "functions.php";?>
<?php
read();
?>